base_date = datenum('jan 1 2006');
end_date = datenum('dec 31 2013');

date_values = base_date:end_date;
num_months = 12;

[month_num,~] = month(date_values);
[~,num_dates] = size(month_num);

file_out = zeros(num_dates,num_months);

for i = 1:num_dates
    file_out(i,month_num(i)) = 1;
end

filename = ['months.csv'];
csvwrite(filename,file_out);

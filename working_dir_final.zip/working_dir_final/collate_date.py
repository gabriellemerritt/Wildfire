# -*- coding: utf-8 -*-
"""
Created on Mon Dec 08 14:29:28 2014

@author: LevLaptop
"""
import numpy as np
from numpy import genfromtxt

county_names = ['alameda', 'alpine', 'amador', 'butte', 'calaveras', 'colusa', 'contracosta', 'delnorte', 'eldorado', 'fresno', 'glenn', 'humboldt', 'imperial', 'inyo', 'kern', 'kings', 'lake', 'lassen', 'losangeles', 'madera', 'marin', 'mariposa', 'mendocino', 'merced', 'modoc', 'mono', 'monterey', 'napa', 'nevada', 'orange', 'placer', 'plumas', 'riverside', 'sacto', 'sanbenito', 'sanbernardino', 'sandiego', 'sanfrancisco', 'sanjoaquin', 'sanluisobispo', 'sanmateo', 'santabarbara', 'santaclara', 'santacruz', 'shasta', 'sierra', 'siskiyou', 'solano', 'sonoma', 'stanislaus', 'sutter', 'tehama', 'trinity', 'tulare', 'tuolumne', 'ventura', 'yolo', 'yuba']
num_counties = len(county_names)

num_dates = 1825

all_data = np.empty((0,0))

for i in range(0,num_counties):
    weather_file = 'weather_data/weather_' + county_names[i] + '.csv'
    weather_data = genfromtxt(weather_file, delimiter=',')
    weather_data = weather_data[:num_dates,:]
    
    land_file = 'land_data/data_'+county_names[i]+'.csv'
    land_data = genfromtxt(land_file,delimiter=',')
    land_data = land_data[:num_dates,:]
    
    holiday_file = 'holiday_data/holidays.csv'
    holiday_data = genfromtxt(holiday_file,delimiter=',')
    holiday_data = holiday_data[:num_dates,:]

    month_file = 'month_data/months.csv'
    month_data = genfromtxt(month_file,delimiter=',')
    month_data = month_data[:num_dates,:]
    
    fire_file = 'fire_data/'+county_names[i]+'_fire_date.csv'
    fire_data = genfromtxt(fire_file,delimiter=',').reshape(-1,1)
    fire_data = fire_data[:num_dates,:]
    
    data_county = np.append(weather_data,land_data,axis=1)
    data_county = np.append(data_county,holiday_data,axis=1)
    data_county = np.append(data_county,month_data,axis=1)
    data_county = np.append(data_county,fire_data,axis=1)
    
    if(i==0):
        n,d = data_county.shape
        all_data = np.empty((0,d))
        
    print county_names[i]
    print weather_data.shape
    print land_data.shape
    print holiday_data.shape
    print month_data.shape
    print fire_data.shape
    
    print all_data.shape
    print data_county.shape
    all_data = np.append(all_data,data_county,axis=0)
    np.savetxt('data_compiled_'+county_names[i]+'.csv',data_county,delimiter=',')

np.savetxt('_all_data.csv',all_data,delimiter=',')
        
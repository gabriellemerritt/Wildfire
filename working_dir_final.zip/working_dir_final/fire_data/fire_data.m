county_names_out = {'alameda' 'alpine' 'amador' 'butte' 'calaveras' 'colusa' 'contracosta' 'delnorte' 'eldorado' 'fresno' 'glenn' 'humboldt' 'imperial' 'inyo' 'kern' 'kings' 'lake' 'lassen' 'losangeles' 'madera' 'marin' 'mariposa' 'mendocino' 'merced' 'modoc' 'mono' 'monterey' 'napa' 'nevada' 'orange' 'placer' 'plumas' 'riverside' 'sacto' 'sanbenito' 'sanbernardino' 'sandiego' 'sanfrancisco' 'sanjoaquin' 'sanluisobispo' 'sanmateo' 'santabarbara' 'santaclara' 'santacruz' 'shasta' 'sierra' 'siskiyou' 'solano' 'sonoma' 'stanislaus' 'sutter' 'tehama' 'trinity' 'tulare' 'tuolumne' 'ventura' 'yolo' 'yuba'};
county_names_in = {'Alameda' 'Alpine' 'Amador' 'Butte' 'Calaveras' 'Colusa' 'Contra Costa' 'Del Norte' 'El Dorado' 'Fresno' 'Glenn' 'Humboldt' 'Imperial' 'Inyo' 'Kern' 'Kings' 'Lake' 'Lassen' 'Los Angeles' 'Madera' 'Marin' 'Mariposa' 'Mendocino' 'Merced' 'Modoc' 'Mono' 'Monterey' 'Napa' 'Nevada' 'Orange' 'Placer' 'Plumas' 'Riverside' 'Sacramento' 'San Benito' 'San Bernardino' 'San Diego' 'San Francisco' 'San Joaquin' 'San Luis Obispo' 'San Mateo' 'Santa Barbara' 'Santa Clara' 'Santa Cruz' 'Shasta' 'Sierra' 'Siskiyou' 'Solano' 'Sonoma' 'Stanislaus' 'Sutter' 'Tehama' 'Trinity' 'Tulare' 'Tuolumne' 'Ventura' 'Yolo' 'Yuba'};

[~,num_counties] = size(county_names_in);

filename = 'county_firesize_date.csv';
fid = fopen(filename);
data = textscan(fid,'%s%f%f','delimiter',',');
fclose(fid);

daterange = datenum('jan 1 2006'):datenum('dec 31 2013');
[~,num_dates] = size(daterange);

[sz_data,~] = size(date);

counties = data{1};
firesize = data{2};
date = data{3};


for j = 1:num_counties
    fire_class = zeros(num_dates,1);
    county_in = county_names_in{j};
    for i = 1:sz_data
        if(strcmp(counties{i},county_in))
            fire_class(date(i)) = fire_class(date(i)) + firesize(i);
            if(fire_class(date(i))>4)
                fire_class(date(i)) = 4;
            end
        end
    end
    filename = [county_names_out{j} '_fire_date.csv'];
    csvwrite(filename,fire_class); 
end
        
    




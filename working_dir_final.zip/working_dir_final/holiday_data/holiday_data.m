base_date = datenum('jan 1 2006') - 1;
num_dates = datenum('dec 31 2013') - datenum('jan 1 2006') + 1;

date_values = datenum('jan 1 2006'):datenum('dec 31 2013');

holidays = isbusday(date_values,[],[0 0 0 0 0 0 0]);
fridays = isbusday(date_values,[0],[0 0 0 0 0 1 0]);
weekends = isbusday(date_values,[0],[1 0 0 0 0 0 1]);

busdays = [holidays fridays weekends];

datestring = datestr(date_values');
offdays = abs(busdays-1);

file_out = ['holidays.csv'];
csvwrite(file_out,offdays);

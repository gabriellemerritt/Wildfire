import numpy as np  
from sklearn.linear_model import LogisticRegression
from numpy import genfromtxt 
from sklearn import preprocessing
from sklearn.metrics import recall_score,precision_score,accuracy_score
from sklearn import svm
import Image

data = genfromtxt('_all_data.csv', delimiter=',')
data = data[~np.isnan(data).any(axis=1)]

X = data[:,:-1]
y = data[:, -1]
n, d = X.shape

nMax = 1000;
nTrain = 0.5*nMax 
idx = np.arange(n)
#np.random.seed()
np.random.shuffle(idx)
X = X[idx]
y = y[idx]

scaler = preprocessing.StandardScaler(copy=True,with_mean=True,with_std=True).fit(X)
X = scaler.transform(X)

# split the data
Xtrain = X[:nTrain, :]
ytrain = y[:nTrain]
Xtest = X[nTrain:nMax, :]
ytest = y[nTrain:nMax]

ytrain_prob = np.copy(ytrain)
ytest_prob = np.copy(ytest)

#Convert to fire/nofire
ytrain[ytrain>1] = 1
ytest[ytest>1] = 1

ly = len(ytest)
py = np.sum(ytest)

print 'Positive rate ', py/ly
print ''

'''
LOGISTIC REGRESSION FOR FIRE/NOFIRE. INFERIOR TO SVM
'''
'''
lr = LogisticRegression(class_weight='auto');
lr.fit(Xtrain,ytrain)
pred_lr = lr.predict(Xtest)
#pred_lr_prob = lr.predict_proba(Xtest)
lr_accw0 = accuracy_score(ytest,pred_lr)
lr_rec = recall_score(ytest,pred_lr)
lr_precc = precision_score(ytest,pred_lr)

print 'lr w/ 0 ',lr_accw0
print 'lr recc ',lr_rec
print 'lr precc ',lr_precc
print ''
'''

'''
TRAIN SVM AND OUTPUT ACCURACY PRECISION AND RECALL FOR FIRE/NOFIRE
'''

'''
clf = svm.SVC(kernel='rbf',class_weight='auto',C=1)
clf.fit(Xtrain,ytrain)
pred_clf = clf.predict(Xtest)
clf_accw0 = accuracy_score(ytest,pred_clf)
clf_rec = recall_score(ytest,pred_clf)
clf_precc = precision_score(ytest,pred_clf)

print 'clf w/ 0', clf_accw0
print 'clf recc',clf_rec
print 'clf precc',clf_precc
print ''
'''

'''
TRAIN SVM WITH PROBABILITIES-FOR HEAT MAP
'''
clf = svm.SVC(kernel='rbf',class_weight='auto',C=1,probability=True)
clf.fit(Xtrain,ytrain_prob)
pred_clf_prob = clf.predict_proba(Xtest)


npr,dpr = pred_clf_prob.shape
if(dpr<5):
    nz = np.zeros((npr,1))
    pred_clf_prob = np.append(pred_clf_prob,nz,axis=1)

#Standardize weighted average of prediction probabilities
y_w_avg = 0*pred_clf_prob[:,0]+1*pred_clf_prob[:,1]+2*pred_clf_prob[:,2]+3*pred_clf_prob[:,3]+4*pred_clf_prob[:,4]
scaler_y = preprocessing.StandardScaler(copy=True,with_mean=True,with_std=True).fit(y_w_avg)

'''
CREATE HEAT MAP FOR RANDOM DAY
'''

nDay = 1824;

#Build feature matrix
county_names = ['alameda', 'alpine', 'amador', 'butte', 'calaveras', 'colusa', 'contracosta', 'delnorte', 'eldorado', 'fresno', 'glenn', 'humboldt', 'imperial', 'inyo', 'kern', 'kings', 'lake', 'lassen', 'losangeles', 'madera', 'marin', 'mariposa', 'mendocino', 'merced', 'modoc', 'mono', 'monterey', 'napa', 'nevada', 'orange', 'placer', 'plumas', 'riverside', 'sacto', 'sanbenito', 'sanbernardino', 'sandiego', 'sanfrancisco', 'sanjoaquin', 'sanluisobispo', 'sanmateo', 'santabarbara', 'santaclara', 'santacruz', 'shasta', 'sierra', 'siskiyou', 'solano', 'sonoma', 'stanislaus', 'sutter', 'tehama', 'trinity', 'tulare', 'tuolumne', 'ventura', 'yolo', 'yuba']
num_counties = len(county_names)

nan_ex = 1
rand_day = np.random.randint(nDay)

feature_data = np.empty((0,0))
for i in range(0,num_counties):
    county_data = genfromtxt('county_data/data_compiled_'+county_names[i]+'.csv', delimiter=',')
    county_data_day = county_data[rand_day,:]
    county_data_day = county_data_day.reshape(1,-1)
    if (i == 0):
        nc,dc = county_data_day.shape
        feature_data = np.empty((0,dc))
    feature_data = np.append(feature_data,county_data_day,axis=0)
if(np.sum(np.isnan(feature_data))!=0):
    print 'NaNs found. They will be set to 0, this may skew results'

feature_data[np.isnan(feature_data)] = 0
feature_data = feature_data[:,:-1]
feature_data = scaler.transform(feature_data)

#Predict probabilities
pred_clf_prob_heat = clf.predict_proba(feature_data)
y_w_avg_heat = 0*pred_clf_prob_heat[:,0]+1*pred_clf_prob_heat[:,1]+2*pred_clf_prob_heat[:,2]+3*pred_clf_prob_heat[:,3]+4*pred_clf_prob_heat[:,4]
y_w_avg_heat = scaler_y.transform(y_w_avg_heat)

y_w_avg_heat = y_w_avg_heat*75+127
y_w_avg_heat[y_w_avg_heat<0] = 0
y_w_avg_heat[y_w_avg_heat>255] = 255

#Make Image
vals = y_w_avg_heat

base = Image.open("images/county_cut__58.png")
base.load()
rb,gb,bb,ab = np.array(base).T

im_paste = Image.fromarray(np.dstack([item.T for item in (rb,gb,bb,ab)]))

base = Image.fromarray(np.dstack([item.T for item in (rb,gb,bb,ab)]))
fil_end = ".png"

for i in range (1,59):
    if (i<10):
        fil_start = "images/county_cut__0";
    if (i>=10):
        fil_start = "images/county_cut__";
        
    rv = vals[i-1]        
        
    filename = fil_start+str(i)+fil_end;
    im_paste = Image.open(filename)
    im_paste.load()
    
    rp,gp,bp,ap = np.array(im_paste).T

    if(rv==0):
        rp[:,:]=255
        gp[:,:]=255
        bp[:,:]=255
    if(rv!=0):
        rp[:,:]=rv
        gp[:,:]=0
        bp[:,:]=0
    im_paste = Image.fromarray(np.dstack([item.T for item in (rp,gp,bp,ap)]))
    
    base.paste(im_paste, (0,0),im_paste)
base.save("firerisk.png")





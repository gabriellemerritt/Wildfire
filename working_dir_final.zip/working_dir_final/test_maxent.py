import numpy as np  
import csv 
from sklearn.linear_model import LogisticRegression
from numpy import genfromtxt 
from sklearn.metrics import accuracy_score
from sklearn import preprocessing
from sklearn.metrics import recall_score,precision_score
from sklearn import svm

data = genfromtxt('_all_data.csv', delimiter=',')
data = data[~np.isnan(data).any(axis=1)]
X = data[:,:-1]
y = data[:, -1]
n, d = X.shape
nMax = 9000;
nTrain = 0.5*nMax 
idx = np.arange(n)
np.random.seed(16)
np.random.shuffle(idx)
X = X[idx]
y = y[idx]

X = preprocessing.scale(X)

# split the data
Xtrain = X[:nTrain, :]
ytrain = y[:nTrain]
Xtest = X[nTrain:nMax, :]
ytest = y[nTrain:nMax]

ytrain[ytrain>1] = 1
ytest[ytest>1] = 1

lr = LogisticRegression(class_weight='auto');
lr.fit(Xtrain,ytrain)
pred_lr = lr.predict(Xtest)
#pred_lr_prob = lr.predict_proba(Xtest)
lr_accw0 = accuracy_score(ytest,pred_lr)
lr_rec = recall_score(ytest,pred_lr)
lr_precc = precision_score(ytest,pred_lr)

ly = len(ytest)
py = np.sum(ytest)

print 'Positive rate ', py/ly
print ''
print 'lr w/ 0 ',lr_accw0
print 'lr recc ',lr_rec
print 'lr precc ',lr_precc
print ''

clf = svm.SVC(kernel='linear',class_weight='auto',C=1)
clf.fit(Xtrain,ytrain)
pred_clf = clf.predict(Xtest)
#pred_clf_prob = clf.predict_log_proba(Xtest)
clf_accw0 = accuracy_score(ytest,pred_clf)
clf_rec = recall_score(ytest,pred_clf)
clf_precc = precision_score(ytest,pred_clf)

print 'clf w/ 0', clf_accw0
print 'clf recc',clf_rec
print 'clf precc',clf_precc
print ''




